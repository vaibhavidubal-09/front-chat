import React, { useEffect, useRef, useState } from "react";
import { MdAttachFile, MdDoneAll, MdSend } from "react-icons/md";
import SockJS from "sockjs-client";
import { Client } from "@stomp/stompjs";
import toast from "react-hot-toast";
import { useChatContext } from "../context/useChatContext";
import {
  getMessagesApi,
  getTeacherClasses,
  getStudentClasses
} from "../services/RoomService";
import { uploadFileApi } from "../services/FileService";
import { formatDateTime } from "../config/helper";

const TYPING_IDLE_MS = 1200;
const USER_EMOJIS = ["🙂", "😎", "🧑", "👩", "👨", "🌟", "🚀", "📘"];

const normalizeMessage = (message) => {
  if (!message || typeof message !== "object") {
    return null;
  }

  const resolvedType = `${message.type || ""}`.toUpperCase();
  const inferredType =
    resolvedType ||
    (message.fileUrl ? "FILE" : message.content ? "TEXT" : "");

  return {
    ...message,
    id:
      message.id ||
      `${message.sender || message.email || "unknown"}-${message.timeStamp || message.timestamp || Date.now()}`,
    sender: message.sender || message.email || "",
    content: message.content || "",
    type: inferredType,
    fileUrl: message.fileUrl || "",
    replyTo: message.replyTo || null,
    timeStamp: message.timeStamp || message.timestamp || message.createdAt || null
  };
};

const normalizeMessages = (payload) => {
  if (Array.isArray(payload)) {
    return payload.map(normalizeMessage).filter(Boolean);
  }

  if (Array.isArray(payload?.messages)) {
    return payload.messages.map(normalizeMessage).filter(Boolean);
  }

  const singleMessage = normalizeMessage(payload);
  return singleMessage ? [singleMessage] : [];
};

const ChatPage = () => {
  const {
    roomId,
    setRoomId,
    currentUserEmail,
    currentUserRole
  } = useChatContext();

  const chatBoxRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const isTypingRef = useRef(false);
  const lastSeenMessageIdRef = useRef(null);

  const [messages, setMessages] = useState([]);
  const [classes, setClasses] = useState([]);
  const [client, setClient] = useState(null);
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [typingUsers, setTypingUsers] = useState([]);
  const [seenByMessage, setSeenByMessage] = useState({});

  const [input, setInput] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedFilePreview, setSelectedFilePreview] = useState("");
  const [sendingFile, setSendingFile] = useState(false);

  const [replyMsg, setReplyMsg] = useState(null);
  const [editMsg, setEditMsg] = useState(null);

  const isClientReady = Boolean(roomId && client?.connected);

  const getReadyClient = () => {
    if (!roomId) {
      toast.error("Select a class first");
      return null;
    }

    if (!client?.connected) {
      toast.error("Chat is still connecting. Please try again.");
      return null;
    }

    return client;
  };

  useEffect(() => {
    const loadClasses = async () => {
      try {
        let res;

        if (currentUserRole === "TEACHER") {
          res = await getTeacherClasses(currentUserEmail);
        } else {
          res = await getStudentClasses(currentUserEmail);
        }

        setClasses(res || []);
      } catch {
        toast.error("Failed to load classes");
      }
    };

    if (currentUserEmail) {
      loadClasses();
    }
  }, [currentUserEmail, currentUserRole]);

  useEffect(() => {
    if (!roomId) return;

    getMessagesApi(roomId)
      .then((data) => {
        setMessages(normalizeMessages(data));
        setSeenByMessage({});
        lastSeenMessageIdRef.current = null;
      })
      .catch(() => toast.error("Failed to load messages"));
  }, [roomId]);

  useEffect(() => {
    chatBoxRef.current?.scrollTo(0, chatBoxRef.current.scrollHeight);
  }, [messages, typingUsers]);

  useEffect(() => {
    if (!selectedFile) {
      setSelectedFilePreview("");
      return;
    }

    const canPreview =
      selectedFile.type.startsWith("image/") ||
      selectedFile.type.startsWith("video/") ||
      selectedFile.type.startsWith("audio/");

    if (!canPreview) {
      setSelectedFilePreview("");
      return;
    }

    const objectUrl = URL.createObjectURL(selectedFile);
    setSelectedFilePreview(objectUrl);

    return () => {
      URL.revokeObjectURL(objectUrl);
    };
  }, [selectedFile]);

  useEffect(() => {
    if (!roomId) {
      setClient(null);
      setTypingUsers([]);
      setOnlineUsers([]);
      return;
    }

    setClient(null);

    const stompClient = new Client({
      webSocketFactory: () => new SockJS("http://localhost:8080/chat"),
      reconnectDelay: 5000,
      onConnect: () => {
        setClient(stompClient);

        stompClient.subscribe(`/topic/room/${roomId}`, (msg) => {
          const incoming = normalizeMessage(JSON.parse(msg.body));
          if (!incoming) return;

          setMessages((prev) => {
            if (prev.some((item) => item.id === incoming.id)) {
              return prev;
            }

            return [...prev, incoming];
          });
          setTypingUsers((prev) =>
            prev.filter((user) => user !== incoming.sender)
          );
        });

        stompClient.subscribe(`/topic/edit/${roomId}`, (msg) => {
          const updated = normalizeMessage(JSON.parse(msg.body));
          if (!updated) return;
          setMessages((prev) =>
            prev.map((m) => (m.id === updated.id ? updated : m))
          );
        });

        stompClient.subscribe(`/topic/delete/${roomId}`, (msg) => {
          const id = msg.body;
          setMessages((prev) => prev.filter((m) => `${m.id}` !== `${id}`));
        });

        stompClient.subscribe(`/topic/online/${roomId}`, (msg) => {
          try {
            const payload = JSON.parse(msg.body);
            setOnlineUsers(Array.isArray(payload) ? payload : []);
          } catch {
            setOnlineUsers([]);
          }
        });

        stompClient.subscribe(`/topic/typing/${roomId}`, (msg) => {
          try {
            const payload = JSON.parse(msg.body);
            const user = payload.user || payload.sender || payload.email;
            const isTyping = Boolean(payload.typing);

            if (!user || user === currentUserEmail) return;

            setTypingUsers((prev) => {
              const next = prev.filter((entry) => entry !== user);
              return isTyping ? [...next, user] : next;
            });
          } catch {
            // Ignore unsupported payloads so the chat stays usable.
          }
        });

        stompClient.subscribe(`/topic/seen/${roomId}`, (msg) => {
          try {
            const payload = JSON.parse(msg.body);
            const messageId = payload.messageId;
            const user = payload.user || payload.seenBy || payload.email;

            if (!messageId || !user || user === currentUserEmail) return;

            setSeenByMessage((prev) => {
              const currentSeen = prev[messageId] || [];
              if (currentSeen.includes(user)) return prev;

              return {
                ...prev,
                [messageId]: [...currentSeen, user]
              };
            });
          } catch {
            // Ignore unsupported payloads so the chat stays usable.
          }
        });

        stompClient.publish({
          destination: `/app/join/${roomId}`,
          body: currentUserEmail
        });
      },
      onDisconnect: () => {
        setClient(null);
      },
      onWebSocketClose: () => {
        setClient(null);
      }
    });

    stompClient.activate();

    return () => {
      if (isTypingRef.current) {
        try {
          stompClient.publish({
            destination: `/app/typing/${roomId}`,
            body: JSON.stringify({
              user: currentUserEmail,
              typing: false
            })
          });
        } catch {
          // Ignore connection cleanup errors.
        }
      }

      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }

      isTypingRef.current = false;
      setClient(null);
      stompClient.deactivate();
    };
  }, [roomId, currentUserEmail]);

  const publishTyping = (typing) => {
    if (!client?.connected || !roomId || !currentUserEmail) return;

    client.publish({
      destination: `/app/typing/${roomId}`,
      body: JSON.stringify({
        user: currentUserEmail,
        typing
      })
    });
  };

  useEffect(() => {
    if (!roomId || !messages.length) return;

    const latestIncoming = [...messages]
      .reverse()
      .find((message) => message.sender !== currentUserEmail);

    if (!client?.connected || !latestIncoming?.id) return;
    if (lastSeenMessageIdRef.current === latestIncoming.id) return;

    lastSeenMessageIdRef.current = latestIncoming.id;

    client.publish({
      destination: `/app/seen/${roomId}`,
      body: JSON.stringify({
        messageId: latestIncoming.id,
        user: currentUserEmail
      })
    });
  }, [messages, roomId, currentUserEmail, client]);

  useEffect(() => {
    if (!roomId || !client?.connected) return;

    const handleFocus = () => {
      const latestIncoming = [...messages]
        .reverse()
        .find((message) => message.sender !== currentUserEmail);

      if (!latestIncoming?.id) return;
      if (lastSeenMessageIdRef.current === latestIncoming.id) return;

      lastSeenMessageIdRef.current = latestIncoming.id;

      client.publish({
        destination: `/app/seen/${roomId}`,
        body: JSON.stringify({
          messageId: latestIncoming.id,
          user: currentUserEmail
        })
      });
    };

    window.addEventListener("focus", handleFocus);
    return () => window.removeEventListener("focus", handleFocus);
  }, [messages, roomId, client, currentUserEmail]);

  const handleInputChange = (event) => {
    const value = event.target.value;
    setInput(value);

    if (!client || !roomId || !currentUserEmail) return;

    const hasContent = value.trim().length > 0;

    if (hasContent) {
      if (!isTypingRef.current) {
        publishTyping(true);
        isTypingRef.current = true;
      }

      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }

      typingTimeoutRef.current = setTimeout(() => {
        publishTyping(false);
        isTypingRef.current = false;
      }, TYPING_IDLE_MS);
    } else if (isTypingRef.current) {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }

      publishTyping(false);
      isTypingRef.current = false;
    }
  };

  const stopTypingNow = () => {
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    if (isTypingRef.current) {
      publishTyping(false);
      isTypingRef.current = false;
    }
  };

  const sendMessage = async () => {
    const activeClient = getReadyClient();
    if (!activeClient) return;

    if (selectedFile) {
      setSendingFile(true);

      try {
        const fileUrl = await uploadFileApi(selectedFile);

        let type = "FILE";
        if (selectedFile.type.startsWith("image")) type = "IMAGE";
        else if (selectedFile.type.startsWith("video")) type = "VIDEO";
        else if (selectedFile.type.startsWith("audio")) type = "AUDIO";

        activeClient.publish({
          destination: `/app/sendMessage/${roomId}`,
          body: JSON.stringify({
            sender: currentUserEmail,
            fileUrl,
            type,
            replyTo: replyMsg?.id
          })
        });

        setSelectedFile(null);
        setReplyMsg(null);
      } catch {
        toast.error("Failed to upload file");
      } finally {
        setSendingFile(false);
      }

      return;
    }

    if (input.trim()) {
      if (editMsg) {
        activeClient.publish({
          destination: `/app/edit/${roomId}`,
          body: JSON.stringify({
            messageId: editMsg.id,
            content: input
          })
        });
        setEditMsg(null);
      } else {
        activeClient.publish({
          destination: `/app/sendMessage/${roomId}`,
          body: JSON.stringify({
            sender: currentUserEmail,
            content: input,
            type: "TEXT",
            replyTo: replyMsg?.id
          })
        });
      }

      stopTypingNow();
      setInput("");
      setReplyMsg(null);
    }
  };

  const deleteMessage = (id) => {
    const activeClient = getReadyClient();
    if (!activeClient) return;

    activeClient.publish({
      destination: `/app/delete/${roomId}`,
      body: id
    });
  };

  const clearSelectedFile = () => {
    setSelectedFile(null);
  };

  const typingLabel = (() => {
    if (typingUsers.length === 0) return "";
    if (typingUsers.length === 1) {
      return `${typingUsers[0].split("@")[0]} is typing...`;
    }

    return `${typingUsers.length} people are typing...`;
  })();

  const formatDisplayName = (email) => {
    const base = (email || "User").split("@")[0];
    return base
      .split(/[._-]+/)
      .filter(Boolean)
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(" ");
  };

  const getInitial = (email) => {
    return formatDisplayName(email).charAt(0).toUpperCase() || "U";
  };

  return (
    <div className="h-screen flex bg-slate-900 text-white">
      <div className="w-72 bg-slate-800 p-4 overflow-y-auto border-r border-slate-700/70">
        <div className="mb-5">
          <p className="text-xs uppercase tracking-[0.2em] text-slate-400">
            Rooms
          </p>
          <h2 className="text-xl font-semibold mt-1">Your classes</h2>
        </div>

        {classes.map((c) => (
          <div
            key={c.roomId}
            onClick={() => setRoomId(c.roomId)}
            className={`p-4 mb-3 rounded-2xl cursor-pointer transition ${
              roomId === c.roomId
                ? "bg-blue-600 shadow-lg shadow-blue-950/50"
                : "bg-slate-700/80 hover:bg-slate-600"
            }`}
          >
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="font-semibold truncate">{c.roomName}</p>
                <p className="text-xs text-gray-300 mt-1">{c.roomId}</p>
              </div>

              {c.meetingActive && (
                <span className="text-[10px] uppercase tracking-wider text-green-300">
                  Live
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="flex-1 flex flex-col bg-slate-900">
        <header className="px-6 py-4 bg-slate-800/95 border-b border-slate-700/70">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h1 className="text-lg font-semibold">
                {roomId ? `Room: ${roomId}` : "Select Class"}
              </h1>
              <p className="text-sm text-slate-300 mt-1 min-h-5">
                {typingLabel ||
                  `${onlineUsers.length} online${onlineUsers.length === 1 ? " person" : " people"}`}
              </p>
            </div>

            <div className="text-xs text-slate-400">
              {currentUserEmail || "Not connected"}
            </div>
          </div>
        </header>

        <main
          ref={chatBoxRef}
          className="flex-1 overflow-y-auto px-4 py-5 space-y-4 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950"
        >
          {messages.map((msg) => {
            const isMe = msg.sender === currentUserEmail;
            const replyToMsg = messages.find((m) => m.id === msg.replyTo);
            const seenUsers = seenByMessage[msg.id] || [];
            const senderName = formatDisplayName(msg.sender);
            const senderMail = msg.sender;

            return (
              <div
                key={msg.id}
                className={`flex ${isMe ? "justify-end" : "justify-start"}`}
              >
                <div className="flex max-w-2xl items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-orange-600 text-sm font-semibold text-white">
                    {getInitial(msg.sender)}
                  </div>
                  <div
                    className={`min-w-[280px] max-w-md rounded-2xl px-4 py-3 shadow-sm ${
                      isMe
                        ? "bg-[#dcf8c6] text-slate-900"
                        : "bg-white text-slate-900"
                    }`}
                  >
                    <div className="mb-2 flex flex-wrap items-center gap-x-2 gap-y-1">
                      <p className="text-sm font-semibold text-orange-700">
                        {senderName}
                      </p>
                      <p className="text-xs text-slate-500">{senderMail}</p>
                    </div>

                    {replyToMsg && (
                      <div className="mb-2 rounded-xl border-l-4 border-emerald-500 bg-slate-100 p-2 text-xs text-slate-700">
                        Reply: {replyToMsg.content || "Media"}
                      </div>
                    )}

                    {(msg.type === "TEXT" || (!msg.type && msg.content)) && (
                      <p>{msg.content}</p>
                    )}
                    {msg.type === "MEETING" && (
                      <div className="space-y-3">
                        <p className="text-sm font-semibold">
                          Online class is live now.
                        </p>
                        <button
                          onClick={() =>
                            window.open(
                              msg.content,
                              "_blank",
                              "noopener,noreferrer"
                            )
                          }
                          className="rounded-xl bg-cyan-400 px-4 py-2 text-sm font-semibold text-slate-950 transition hover:bg-cyan-300"
                        >
                          Join Meeting
                        </button>
                      </div>
                    )}
                    {msg.type === "IMAGE" && (
                      <img src={msg.fileUrl} className="max-w-xs mt-2 rounded-xl" />
                    )}
                    {msg.type === "VIDEO" && (
                      <video controls className="max-w-xs mt-2 rounded-xl">
                        <source src={msg.fileUrl} />
                      </video>
                    )}
                    {msg.type === "AUDIO" && (
                      <audio controls className="mt-2">
                        <source src={msg.fileUrl} />
                      </audio>
                    )}
                    {msg.type === "FILE" && msg.fileUrl && (
                      <a
                        href={msg.fileUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-2 inline-block text-sm font-medium text-blue-600 underline"
                      >
                        Open attachment
                      </a>
                    )}
                    {!["TEXT", "MEETING", "IMAGE", "VIDEO", "AUDIO", "FILE"].includes(msg.type) &&
                      msg.content && <p>{msg.content}</p>}

                    <div className="mt-3 flex gap-3 text-xs text-slate-500">
                      <button onClick={() => setReplyMsg(msg)}>Reply</button>

                      {isMe && (
                        <>
                          <button
                            onClick={() => {
                              setEditMsg(msg);
                              setInput(msg.content || "");
                            }}
                          >
                            Edit
                          </button>
                          <button onClick={() => deleteMessage(msg.id)}>
                            Delete
                          </button>
                        </>
                      )}
                    </div>
                    <div
                      className={`mt-2 flex items-center gap-2 text-[11px] text-slate-500 ${
                        isMe ? "justify-end" : "justify-start"
                      }`}
                    >
                      <span>{formatDateTime(msg.timeStamp)}</span>

                      {isMe && seenUsers.length > 0 && (
                        <span className="inline-flex items-center gap-1 text-emerald-600">
                          <MdDoneAll />
                          Seen by {seenUsers.length}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {typingUsers.length > 0 && (
            <div className="flex justify-start">
              <div className="bg-slate-700 rounded-2xl rounded-bl-md px-4 py-3 text-sm text-slate-200">
                {typingLabel}
              </div>
            </div>
          )}
        </main>

        {replyMsg && (
          <div className="bg-slate-800 mx-4 mb-3 px-4 py-3 rounded-2xl border border-slate-700 flex justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs uppercase tracking-wider text-slate-400">
                Replying
              </p>
              <p className="text-sm truncate">{replyMsg.content || "Media"}</p>
            </div>
            <button onClick={() => setReplyMsg(null)} className="text-slate-300">
              Cancel
            </button>
          </div>
        )}

        {selectedFile && (
          <div className="bg-slate-800 mx-4 mb-3 px-4 py-3 rounded-2xl border border-slate-700">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-semibold">File ready to send</p>
                <p className="text-xs text-slate-300 truncate mt-1">
                  {selectedFile.name}
                </p>
              </div>

              <button
                onClick={clearSelectedFile}
                className="text-sm text-slate-300 hover:text-white"
                disabled={sendingFile}
              >
                Remove
              </button>
            </div>

            {selectedFile.type.startsWith("image/") && selectedFilePreview && (
              <img
                src={selectedFilePreview}
                alt={selectedFile.name}
                className="mt-3 max-h-52 rounded-xl"
              />
            )}

            {selectedFile.type.startsWith("video/") && selectedFilePreview && (
              <video
                controls
                src={selectedFilePreview}
                className="mt-3 max-h-52 rounded-xl w-full"
              />
            )}

            {selectedFile.type.startsWith("audio/") && selectedFilePreview && (
              <audio controls src={selectedFilePreview} className="mt-3 w-full" />
            )}

            {!selectedFile.type.startsWith("image/") &&
              !selectedFile.type.startsWith("video/") &&
              !selectedFile.type.startsWith("audio/") && (
                <p className="mt-3 text-xs text-slate-300">
                  Press send to upload this file to the chat.
                </p>
              )}
          </div>
        )}

        <div className="bg-slate-800 border-t border-slate-700/70 p-4">
          <div className="flex gap-3 items-end">
            <input
              value={input}
              onChange={handleInputChange}
              placeholder="Type message..."
              disabled={!roomId}
              className="flex-1 px-4 py-3 rounded-2xl bg-slate-700 outline-none border border-slate-600 focus:border-blue-400"
            />

            <input
              type="file"
              id="filePicker"
              className="hidden"
              onChange={(e) => setSelectedFile(e.target.files[0] || null)}
            />

            <button
              onClick={() => document.getElementById("filePicker").click()}
              disabled={!roomId || !isClientReady}
              className="bg-slate-700 hover:bg-slate-600 p-3 rounded-2xl transition"
            >
              <MdAttachFile />
            </button>

            <button
              onClick={sendMessage}
              disabled={sendingFile || !roomId || !isClientReady}
              className="bg-emerald-600 hover:bg-emerald-500 p-3 rounded-2xl transition disabled:opacity-60"
            >
              <MdSend />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;
